package main_test

import (
	"fmt"
	"main/dockerutils"
	"os"
	"testing"
)

func TestExecuteCode(t *testing.T) {
	snippets := map[string]string{
		".ts": "fibonacci.ts",
	}
	fmt.Println(snippets)

	for ext, filename := range snippets {
		code, err := os.ReadFile(filename)
		if err != nil {
			t.Errorf("Error reading file %s: %v", filename, err)
			continue
		}

		dockerutils.ExecuteCode(ext, string(code))
	}
}
